time_t parseDate(const char * date, const char * time){
    struct tm ti = {0};
    if(sscanf(date, "%d-%d-%d", &ti.tm_year, &ti.tm_mon, &ti.tm_mday) != 3){
		return 1;
    }
    if(sscanf(time, "%d:%d:%d", &ti.tm_hour, &ti.tm_min, &ti.tm_sec) != 3){
		return 1;
    }
	ti.tm_year -= 1900;
    ti.tm_mon -= 1;

    return mktime(&ti);
}

int isNumber(char c){
	return (c >= '0' && c <= '9');
}

int isEmail(const char* email){
	char user[4096];
	char domain[4096];
	
	if(sscanf(email, "%[_a-zA-Z0-9.]@%[_a-zA-Z0-9.]", user, domain) != 2){
		return 1;
    }
	return 0;
}

int isDate(char* date){
	if(strlen(date) != 10){
		return 0;
	}else{
		for(int i = 0; i < strlen(date); i++){
			if (i == 4 || i == 7){
				if(date[i] != '-'){
					return 0;
				}
			}else if(!isNumber(date[i])){
				return 0;
			}
		}
		int daysinmonth[12]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		char year[5]; memcpy(year, &date[0], 4 ); year[4] = '\0';
		char month[3]; memcpy(month, &date[5], 2 ); month[2] = '\0';
		char day[3]; memcpy(day, &date[8], 2 ); day[2] = '\0';

		if(atoi(year) % 400 == 0 || (atoi(year) % 100 != 0 && atoi(year) % 4 == 0))
    		daysinmonth[1]=29;
		
		if(atoi(month) > 12){
			return 0;
		}
		
		if(atoi(day) > daysinmonth[atoi(month)-1]){
			return 0;
		}
		
		return 1;
	}
}

int isTime(char* time){
	if(strlen(time) != 8){
		return 0;
	}else{
		for(int i = 0; i < strlen(time); i++){
			if (i == 2 || i == 5){
				if(time[i] != ':'){
					return 0;
				}
			}else if(!isNumber(time[i])){
				return 0;
			}
		}
	}
	
	char hours[3]; memcpy(hours, &time[0], 2 ); hours[2] = '\0';
	char minutes[3]; memcpy(minutes, &time[3], 2 ); minutes[2] = '\0';
	char seconds[3]; memcpy(seconds, &time[6], 2 ); seconds[2] = '\0';
	
	if(atoi(hours) < 0 || atoi(hours) > 23){
		return 0;
	}
	
	if(atoi(minutes) < 0 || atoi(minutes) > 59){
		return 0;
	}
	
	if(atoi(seconds) < 0 || atoi(seconds) > 59){
		return 0;
	}
	return 1;
}

int nSpaces(char* str){
	int i = 0;
	int count = 0;
	while (str[i] != '\0'){
		if (str[i] == ' ') count++;
		i++;
	}
	return count;
}