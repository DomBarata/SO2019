#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include "myfuncs.c"

typedef int bool;
#define true 1
#define false 0
#define MAX 4096
#define FIFO "/tmp/so_g2"

typedef struct Agenda {
	int      id;
	bool	 status;
	long int datetime;
	char	 commands[MAX];
	int      exitCode;
	char     stdOut[MAX];
	char     stdErr[MAX];
	int		 pid;
	int		 pipeStdOut[2];
	int		 pipeStdErr[2];
	struct Agenda* next;
} agenda, *tAgenda;

tAgenda headQueue = NULL;
tAgenda headDone = NULL;
int     nTasks = 2;
char	adminEmail[MAX] = "mpereira@localhost";

void controlC(){
	unlink(FIFO);
	exit(0);
}

void list(tAgenda head, char* message){
	char line[MAX+5];
	char formatedDate[20];
	struct tm *date;

	while(head != NULL){
		date = localtime(&head->datetime);
		strftime(formatedDate, 20, "%Y-%m-%d %H:%M:%S", date);
		snprintf(line, MAX+5, "%i %s %s\n", head->id, formatedDate, head->commands);
		strcat(message, line);
		head = head->next;
	}
}

tAgenda findByPID(tAgenda head, int pid){
	while(head != NULL && head->pid != pid){
		head = head->next;
	}
	return head;
}

tAgenda newAgenda(int* id, char* datetime, char* commands, char* message){
	if (atol(datetime) < time(NULL)){
		snprintf(message, MAX, "Data/Hora errada\n");
		return NULL;
	}
	tAgenda new;
	new = (tAgenda)malloc(sizeof(agenda));
	new->id = *id;
	(*id)++;
	new->status = false;
	new->datetime = atol(datetime);
	snprintf(new->commands, MAX, "%s", commands);
	new->next = NULL;
	return new;
}

tAgenda addOrdered(tAgenda head, tAgenda new, char* message){
	if(head == NULL || new->datetime < head->datetime){
		new->next = head;
		return new;
	}else{
		head->next = addOrdered(head->next, new, message);
	}
}

int add(tAgenda* head, tAgenda new, char* message){
	if(new != NULL){
		*head = addOrdered(*head, new, message);
		snprintf(message, MAX, "%i\n", new->id);
		return 0;
	}else{
		return 1;
	}
}

tAgenda cancelTask(tAgenda head, int id, char* message){
	if(head == NULL){
		snprintf(message, MAX, "Comando ou argumento inválido\n");
		return head;
	}else if(head->id == id){
		 return head->next;
	}else{
		head->next = cancelTask(head->next, id, message);
	}
}

int cancel(tAgenda* head, char* id, char* message){
	if(atoi(id)){
		*head = cancelTask(*head, atoi(id), message);
		return 0;
	}else{
		return 1;
	}
}

int result(tAgenda head, char* id, char* message){
	int idToFind = atoi(id);
	char line[MAX*4];
	char formatedDate[20];
	struct tm *date;
	if(idToFind){
		while(head != NULL && head->id != idToFind){
			head = head->next;
		}
		if(head != NULL){
			date = localtime(&head->datetime);
			strftime(formatedDate, 20, "%Y-%m-%d %H:%M:%S", date);
			snprintf(line, MAX*4, "Id:\n%i\n\nData:\n%s\n\nLinha de comando:\n%s\n\nValor de saida:\n%i\n\nStandard Output:\n%s\n\nStandard Error:\n%s\n", head->id, formatedDate, head->commands, head->exitCode, head->stdOut, head->stdErr);
			strcat(message, line);
			return 0;
		}else{
			snprintf(message, MAX, "Comando ou argumento inválido\n");
			return 1;
		}
	}else{
		snprintf(message, MAX, "Comando ou argumento inválido\n");
		return 2;
	}
}

int changeEmail(char* email, char* adminEmail, char* message){
	if(isEmail(email) != 0){
		snprintf(message, MAX, "Endereço de email invalido\n");
		return 1;
	}
	snprintf(adminEmail, MAX, "%s", email);
	snprintf(message, MAX, "Endereço de email alterado\n");
	return 0;
}

int changeNTasks(char* n, int* nTasks, char* message){
	if(atoi(n)){
		*nTasks = atoi(n);
		snprintf(message, MAX, "Numero de tarefas concorrentes alterado\n");
		return 0;
	}
	snprintf(message, MAX, "Numero de tarefas concorrentes invalido \n");
	return 1;
}

void setAlarm(tAgenda head){
	int countExecuting = 0;
	while(head != NULL && countExecuting < nTasks && head->status == true){
		head = head->next;
		countExecuting++;
	}

	if (head == NULL){
		//everything is executing or no tasks
	}else if (countExecuting == nTasks){
		//max tasks
	}else{
		if (head->datetime - time(NULL) <= 0){
			alarm(1);
		}else{
			alarm(head->datetime - time(NULL));
		}
	}
}

void execTask(){
	tAgenda head = headQueue;
	int countExecuting = 0;
	while(head != NULL && countExecuting < nTasks && head->status == true){
		head = head->next;
		countExecuting++;
	}

	if (head == NULL){
		//everything is executing or no tasks
	}else if (countExecuting == nTasks){
		//max tasks
	}else{
		int nElem;
		pipe(head->pipeStdOut);
		pipe(head->pipeStdErr);

		head->status = true;
		head->pid = fork();
		if (head->pid == 0){
			close(head->pipeStdOut[0]);
			close(head->pipeStdErr[0]);

			int nElem = nSpaces(head->commands);
			char* arguments[nElem+1];
			char* command = strtok(head->commands, " ");
			arguments[0] = command;

			for (int i = 1; i < nElem; i++){
				arguments[i] = strtok(NULL, " ");
			}
			arguments[nElem] = NULL;

			dup2(head->pipeStdOut[1], 1);close(head->pipeStdOut[1]);
			dup2(head->pipeStdErr[1], 2);close(head->pipeStdErr[1]);
			execvp(command, arguments);
			exit(5);
		}
		close(head->pipeStdOut[1]);
		close(head->pipeStdErr[1]);
	}
}

void sendEmail(tAgenda task){
	int p[2];
	pipe(p);
	if (!fork()){
		close(p[1]);
		dup2(p[0], 0);close(p[0]);
		execlp("mail", "mail", "-s", task->commands, adminEmail, NULL);
		exit(1);
	}
	close(p[0]);

	char line[MAX*4];
	char formatedDate[20];
	struct tm *date = localtime(&task->datetime);
	strftime(formatedDate, 20, "%Y-%m-%d %H:%M:%S", date);
	snprintf(line, MAX*4, "Id:\n%i\n\nData:\n%s\n\nLinha de comando:\n%s\n\nValor de saida:\n%i\n\nStandard Output:\n%s\n\nStandard Error:\n%s\n", task->id, formatedDate, task->commands, task->exitCode, task->stdOut, task->stdErr);
	write(p[1], line, strlen(line));

	close(p[1]);

}

void pipeClosed(){
	char resp[MAX];
	int n;
	pid_t pid;
    int status;
	tAgenda task;
	char number[11];

    while ((pid = waitpid(-1, &status, WNOHANG)) > 0){
			task = findByPID(headQueue, pid);

			if(task != NULL){
				n = read(task->pipeStdOut[0], resp, MAX);
				close(task->pipeStdOut[0]);
				snprintf(task->stdOut, n, "%s", resp);

				n = read(task->pipeStdErr[0], resp, MAX);
				close(task->pipeStdErr[0]);
				snprintf(task->stdErr, n, "%s", resp);

				snprintf(number, 11, "%d", task->id);
				cancel(&headQueue, number, resp);
				task->next = NULL;
				add(&headDone, task, resp);

				if (WIFEXITED(status)) {
					task->exitCode = WEXITSTATUS(status);
				}
				setAlarm(headQueue);
				sendEmail(task);
			}
    }
}

void segFault(){
	printf("Erro!"); fflush(stdout);
}

int main(int argc, char *argv[]){
	const   char delim[2] = ";";
	int     fromClient;
	int     toClient;
	char*   tempFIFO;
	int     n, idCount = 1;
	char    inData[MAX];
	char    outData[MAX];
	char* 	option;
	int		res;
	char	message[MAX] = "";
	char*	temp;
	char*	datetime;
	char*	commands;

	tAgenda tempAgenda = NULL;

	if(access(FIFO, W_OK) == -1){
		if(mkfifo(FIFO, 0622) != 0){
			perror("Erro");
		}
	}

	signal(SIGALRM, execTask);
	signal(SIGINT, controlC);
	signal(SIGCHLD, pipeClosed);
	signal(SIGSEGV, segFault);

	while(1){
		memset(inData, 0, MAX);
		memset(message, 0, MAX);
		fromClient = open(FIFO, O_RDONLY, 0400);
		n = read(fromClient, inData, MAX);
		close(fromClient);

		tempFIFO = strtok(inData, delim);
		if(access(tempFIFO, W_OK) == -1){
			//perror("Error");
			exit(-1);
		}

		option = strtok(NULL, delim);
		switch(option[0]){
			case 'a':
				datetime = strtok(NULL, delim);
				commands = strtok(NULL, delim);
				tempAgenda = newAgenda(&idCount, datetime, commands, message);
				res = add(&headQueue, tempAgenda, message);
				setAlarm(headQueue);
				break;
			case 'l':
				strcat(message, "agendadas:\n");
				list(headQueue, message);
				strcat(message, "executadas:\n");
				list(headDone, message);
				break;
			case 'c':
				temp = strtok(NULL, delim);
				res = cancel(&headQueue, temp, message);
				setAlarm(headQueue);
				break;
			case 'r':
				temp = strtok(NULL, delim);
				res = result(headDone, temp, message);
				break;
			case 'e':
				temp = strtok(NULL, delim);
				res = changeEmail(temp, adminEmail, message);
				break;
			case 'n':
				temp = strtok(NULL, delim);
				res = changeNTasks(temp, &nTasks, message);
				break;
			default:
				res = -1;
				snprintf(message, MAX, "Opcao invalida");
		}
		snprintf(outData, MAX, "%i;%s", res, message);

		toClient = open(tempFIFO, O_WRONLY, 0002);
		write(toClient, outData, strlen(outData));
		close(toClient);
	}
	usleep(100000);
	exit(0);
}
