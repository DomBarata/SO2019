#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include "myfuncs.c"

#define MAX 4096
#define FIFO "/tmp/so_g2"

int add(char* data, char* tempFIFO, char *args[], int argc){
	int n, i;
	long int datetime;
	char commands[MAX];
	
	if(!isDate(args[0])){
		printf("Data errada\n");
		return (1);
	}
	
	if(!isTime(args[1])){
		printf("Hora errada\n");
		return (2);
	}
	
	datetime = parseDate(args[0], args[1]);
	if (datetime < time(NULL)){
		printf("Data/Hora errada\n");
		return (3);
	}
	
	for(i = 2; i < argc; i++){
		strcat(commands, args[i]);
		strcat(commands, " ");
	}
	
	snprintf(data, MAX, "%s;%c;%lu;%s", tempFIFO, 'a', datetime, commands);

	return (0);
}

int list(char* data, char* tempFIFO){

	snprintf(data, MAX, "%s;%c", tempFIFO, 'l');

	return (0);
}

int cancel(char* data, char* tempFIFO, char *args[]){
	if (atoi(args[0])){
		snprintf(data, MAX, "%s;%c;%i", tempFIFO, 'c', atoi(args[0]));
		return (0);
	}
	printf("ID invalido\n");
	return (1);
}

int result(char* data, char* tempFIFO, char *args[]){
	if (atoi(args[0])){
		snprintf(data, MAX, "%s;%c;%i", tempFIFO, 'r', atoi(args[0]));
		return (0);
	}
	printf("ID invalido\n");
	return (1);
}

int email(char* data, char* tempFIFO, char *args[]){
	if(isEmail(args[0]) == 0){
		snprintf(data, MAX, "%s;%c;%s", tempFIFO, 'e', args[0]);
		return (0);
	}
	printf("Endereco invalido\n");
	return 1;
}

int ntasks(char* data, char* tempFIFO, char *args[]){
	if(atoi(args[0])){
		snprintf(data, MAX, "%s;%c;%d", tempFIFO, 'n', atoi(args[0]));
		return (0);
	}
	printf("Valor invalido\n");
	return 1;
}

int main(int argc, char *argv[]){
	const   char delim[2] = ";";
	int toServer;
	int fromServer;
	int n, i;
	char tempFIFO[50];
	char data[MAX];
	char response[MAX];
	char* exitCode;
	int error;
	char message[MAX];
	
	char buffer[MAX];
	char enter='\n';
	char option;
	
	if(access(FIFO, R_OK) == -1){
		perror("Error");
		exit(-1);
	}
	
	snprintf(tempFIFO, sizeof(tempFIFO), "/tmp/so_g2_%d", getpid());
	if(access(tempFIFO, W_OK) == -1){
		if(mkfifo(tempFIFO, 0622) != 0){
			perror("Error");
			exit(-1);
		}
	}
	
	if (argc>1){
		if(strlen(argv[1]) == 2 && argv[1][0] == '-'){
			option = argv[1][1];
			switch(option){
				case 'a':
					if(argc > 4)
						error = add(data, tempFIFO, &argv[2], argc-2);
					else
						error = -1;
						snprintf(message, MAX, "Argumentos insuficientes\n");
					break;
				case 'l':
					error = list(data, tempFIFO);
					break;
				case 'c':
					if(argc > 2)
						error = cancel(data, tempFIFO, &argv[2]);
					else
						error = -1;
						snprintf(message, MAX, "Argumentos insuficientes\n");
					break;
				case 'r':
					if(argc > 2)
						error = result(data, tempFIFO, &argv[2]);
					else
						error = -1;
						snprintf(message, MAX, "Argumentos insuficientes\n");
					break;
				case 'e':
					if(argc > 2)
						error = email(data, tempFIFO, &argv[2]);
					else
						error = -1;
						snprintf(message, MAX, "Argumentos insuficientes\n");
					break;
				case 'n':
					if(argc > 2)
						error = ntasks(data, tempFIFO, &argv[2]);
					else
						error = -1;
						snprintf(message, MAX, "Argumentos insuficientes\n");
					break;
				default:
					printf("Opcao invalida\n");
			}
			
			if(!error){
				memset(response, 0, MAX);
				toServer = open(FIFO, O_WRONLY, 0002);
				write(toServer, data, strlen(data));
				close(toServer);

				fromServer = open(tempFIFO, O_RDONLY, 0400);
				while(n = read(fromServer, response, MAX)){
					exitCode = strtok(response, delim);
					if(!atoi(exitCode)){
						write(1, strtok(NULL, delim), n);
					}
				}
				close(fromServer);
			}else{
				write(1, message, strlen(message));
			}
			usleep(100000);
			unlink(tempFIFO);
		}
	}else{
		printf("Argumentos insuficientes\n");
	}
}